class Product {
    constructor(name, description, price, quantity){
        this.name = name
        this.description = description
        this.price = price
        this.quantity = quantity
    }
    getTotalPrice(){
        if( this.quantity <= 0 || this.price <= 0 ){
            return undefined
        }else{
            return this.quantity * this.price
    }

}
    sell(quantity){
        if(this.quantity < quantity && quantity <= 0 ){ // ถ้าquantityที่รับเข้ามาน้อยกว่า และเป็นจำนวนเต็มบวก
            return undefined
        }else{
            this.quantity -= quantity
            return {name: this.name,quantity: this.quantity}
        }
    }
}
const pd1 = new Product('My Product', 'my product', 99.99, 5);
console.log(pd1.getTotalPrice()) 
console.log(pd1.sell(5)) // reduces quantity to 5 and returns { name: 'My Product', quantity: 5 }
console.log('--------------------');
const pd2 = new Product('My Product', 'my product', -1, 0);
console.log(pd2.getTotalPrice()) 
console.log(pd2.sell(3)) // reduces quantity to 5 and returns { name: 'My Product', quantity: 0 }

// const pd = new Product()
// console.log(pd.getTotalPrice(-1,1));
// console.log(pd.getTotalPrice(11,3));
// console.log(pd.sell('mama',3));
// console.log(pd.sell('mama',2));